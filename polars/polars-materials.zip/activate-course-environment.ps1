# In this script we :
# - activate the virtual environment
# If you have any issues with installation contact me at liam@rhosignal.com

# Activate the virtual environment so that you can run python from this environment
.\course_env\Scripts\Activate.ps1
# Having any issues?
# If the environment is active the command prompt in powershell should start with (course_env)
# Once the virtual environment is active you should be able to run 
# the notebooks with this command: jupyter lab
